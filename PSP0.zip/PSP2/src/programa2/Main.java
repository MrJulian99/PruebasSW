package programa2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

public class Main {

	public static void main(String[] args) {
		
		LinkedList<ParNumeros> list= new LinkedList<ParNumeros>();
        Metodos obj = new Metodos();
        ParNumeros par;
        double Xk = 386;
		String EPS="C:\\Users\\Victor Julian\\Desktop\\PARES\\EstimatedProxySize.txt";		
		String AAMS="C:\\Users\\Victor Julian\\Desktop\\PARES\\ActualAddedAndModifiedSize.txt";
		
		
		
		
		//Obtenemos todos los pares de reales.
		list = obj.obtenerPar(list, EPS, AAMS);
		//Calculamos los parametros de regresion �0 y �1.
		double reg�1=obj.calcular�1(list);
		double reg�0=obj.calcular�0(reg�1);
		//Calculamos los coeficientes de correlacion rxy , r^2.
		double corrRxy= obj.corrRxy(list);
		double corrR2 = obj.corrR2(corrRxy);
		//Dado un estimado de Xk calcular una prediccion mejorada Yk = �0 + �1Xk 
		double predYk= obj.predYk(reg�1,reg�0,Xk);
		
		//par = list.get(0);
		//System.out.println(par.num1);
		//System.out.println(par.num2);
		
		
	}

}
