package programa2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.LinkedList;
import java.util.List;

public class Metodos {

	//num1 = x, num2=y.
	//EPS:Estimated proxy size.
	//AAMS:Actual Added And Modified Size
	ParNumeros par;
	double reg�1;
	double xavg;
	double yavg;
	double sumatoriax;
	double sumatoriay;
	double sumatoriaxpory;
	double sumatoriacuadradox;
	double sumatoriacuadradoy;
	
	
	
	public LinkedList  obtenerPar(LinkedList<ParNumeros> list,String ruta1, String ruta2){	    
	
	File file1 = new File(ruta1);
	File file2 = new File(ruta2);
	
	BufferedReader reader1 = null;
	BufferedReader reader2 = null;

	try {
	    reader1 = new BufferedReader(new FileReader(file1));
	    reader2 = new BufferedReader(new FileReader(file2));
	    String text1 = null;
	    String text2 = null;

	    while ((text1 = reader1.readLine()) != null  && (text2 = reader2.readLine()) != null ) {
	    	 par = new ParNumeros(Double.parseDouble(text1),Double.parseDouble(text2));
	    	
	        list.add(par);
	    }
	} catch (FileNotFoundException e) {
	    e.printStackTrace();//Herramienta de diagnostico de exceptions que Nos dice que paso y en que parte del codigo.
	} catch (IOException e) {
	    e.printStackTrace();
	} finally {
	    try {
	        if ((reader1 != null)&&(reader2 != null) ){
	            reader1.close();
	            reader2.close();
	        }
	    } catch (IOException e) {
	    }
	}

	//Imprime la lista
	  //par = list.get(0);
	  //System.out.println(par.num1);
	  //System.out.println(par.num2);
	
	return list;
	}
	
	
	
	public double calcular�1(LinkedList<ParNumeros> list){
		double numerador;
		double denominador;
		
		if(list.size()!=0)
		{
		
		for(int i=0;i<list.size(); i++) {
			        			
			        par = list.get(i);
					sumatoriax = sumatoriax+par.num1;
					sumatoriay = sumatoriay+par.num2;
					sumatoriaxpory = sumatoriaxpory+(par.num1*par.num2);
					sumatoriacuadradox = sumatoriacuadradox + Math.pow(par.num1,2);
					sumatoriacuadradoy = sumatoriacuadradoy + Math.pow(par.num2,2);
				}	    
				
		xavg = sumatoriax/list.size();	
		yavg = sumatoriay/list.size();
		numerador = sumatoriaxpory - (list.size()*xavg*yavg);
		denominador  = sumatoriacuadradox - (list.size()*Math.pow(xavg, 2));
		reg�1 = numerador/denominador;
		
		//DecimalFormat df = new DecimalFormat("#.##");		
		//double avgf = Double.parseDouble(df.format(avg));
		//System.out.println("Media1: "+xavg);
		//System.out.println("Media2: "+yavg);
		System.out.println("reg �1: "+reg�1);
		return reg�1;
		}else{
			System.out.println("La lista no contiene elementos");
			double x = Math.sqrt(-1);
			return x;
		}
	
	
	}
	
	
    public double calcular�0(double reg�1){
        double reg�0 = 0;	           
        reg�0 = yavg - (reg�1*xavg);		
        System.out.println("reg �0: "+reg�0);
		return reg�0;
	}
		
		
	public double corrRxy(LinkedList<ParNumeros> list){
		double corrRxy=0;
		double numerador;
		double denominador;		
		numerador = (list.size()*sumatoriaxpory) - ((sumatoriax)*(sumatoriay)) ;
		
		double p1= (list.size()*sumatoriacuadradox)- Math.pow(sumatoriax, 2) ;
		double p2 = (list.size()*sumatoriacuadradoy)- Math.pow(sumatoriay, 2);
		denominador = Math.sqrt(p1*p2);
		corrRxy=numerador/denominador;
		System.out.println("Correlacion rxy: "+ corrRxy);				
		return corrRxy;
	}
	
	
	public double corrR2(double corrRxy){
		double corrR2=0;
		corrR2=Math.pow(corrRxy, 2);
		System.out.println("Correlacion R^2: "+ corrR2);				
		return corrR2;
	}
	
	
	public double predYk(double reg�1,double reg�0,double Xk){
		double predYk=0;
		predYk=reg�0 + (reg�1*Xk);		
		System.out.println("Prediccion mejorada Yk: "+ predYk);
		return predYk;
	}
	
	
	
}
