package programa2;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

import org.junit.Test;

public class PSP2Pruebas {

	
	Metodos obj = new Metodos();
	@Test
	public void testcalcular�1() {
		//ARRANGE
		LinkedList<ParNumeros> list= new LinkedList<ParNumeros>();
		String EPS="C:\\Users\\Victor Julian\\Desktop\\PARES\\EstimatedProxySize.txt";		
		String AAMS="C:\\Users\\Victor Julian\\Desktop\\PARES\\ActualAddedAndModifiedSize.txt";
		String ADH="C:\\Users\\Victor Julian\\Desktop\\PARES\\ActualDevelopmentHours.txt";
		String PAAMS="C:\\Users\\Victor Julian\\Desktop\\PARES\\PlannAddedAndModifiedSize.txt";
		ParNumeros par;
		double Xk = 386;
		File file1 = new File(EPS);
		File file2 = new File(AAMS);
		
		BufferedReader reader1 = null;
		BufferedReader reader2 = null;

		try {
		    reader1 = new BufferedReader(new FileReader(file1));
		    reader2 = new BufferedReader(new FileReader(file2));
		    String text1 = null;
		    String text2 = null;

		    while ((text1 = reader1.readLine()) != null  && (text2 = reader2.readLine()) != null ) {
		    	 par = new ParNumeros(Double.parseDouble(text1),Double.parseDouble(text2));
		    	
		        list.add(par);
		    }
		} catch (FileNotFoundException e) {
		    e.printStackTrace();//Herramienta de diagnostico de exceptions que Nos dice que paso y en que parte del codigo.
		} catch (IOException e) {
		    e.printStackTrace();
		} finally {
		    try {
		        if ((reader1 != null)&&(reader2 != null) ){
		            reader1.close();
		            reader2.close();
		        }
		    } catch (IOException e) {
		    }
		}		
		//ACT
		double �1 = obj.calcular�1(list);
		double reg�0=obj.calcular�0(�1);
		double corrRxy= obj.corrRxy(list);
		double corrR2 = obj.corrR2(corrRxy);
		double predYk= obj.predYk(�1,reg�0,Xk);
		//ASSERT
		assertTrue(�1==1.727932426206986 && reg�0==-22.552532752034267 && corrRxy==0.9544965741046826 && corrR2==0.9110637099775758 && predYk==644.4293837638623 );
	}

}
