package programa2;

public class ParNumeros {

	 double num1;
	 double num2;
	 
	 public ParNumeros(double a, double b)
	   {
	     num1 = a; num2 = b; 
	   }
}
